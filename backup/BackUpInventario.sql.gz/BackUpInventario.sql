CREATE DATABASE IF NOT EXISTS inventario;

USE `inventario`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `area`;

CREATE TABLE `area` (
  `idArea` tinyint(3) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idArea`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `area` VALUES (1,"SRYS",1),
(2,"\tADAF\t",1),
(3,"\tSADCTI\t",1),
(4,"\tADJ\t",1),
(5,"\tADR\t",1),
(6,"\tADSC\t",1),
(7,"SAT",1);


DROP TABLE IF EXISTS `asignaciones`;

CREATE TABLE `asignaciones` (
  `idAsignaciones` int(11) NOT NULL AUTO_INCREMENT,
  `idProducto` tinyint(3) NOT NULL,
  `fechaHora` date DEFAULT NULL,
  `idDispositivo` tinyint(3) NOT NULL,
  `numeroSerie` varchar(60) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idAsignaciones`),
  KEY `fk_Asignaciones_Producto1_idx` (`idProducto`),
  KEY `fk_Asignaciones_Dispositivo1_idx` (`idDispositivo`),
  CONSTRAINT `fk_Asignaciones_Dispositivo1` FOREIGN KEY (`idDispositivo`) REFERENCES `dispositivo` (`idDispositivo`),
  CONSTRAINT `fk_Asignaciones_Producto1` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `asignaciones` VALUES (1,1,"2023-08-18",1,"\t74650280218G7\t",1),
(2,2,"2023-08-19",2,"\t74650290219F7\t",1),
(3,3,"2023-08-20",3,"\t74650280218KD\t",1),
(4,4,"2023-08-21",4,"\t 74650280218B3\t",1),
(5,5,"2023-08-22",5,"\t74650270217H3\t",1),
(6,6,"2023-08-23",6,"\t74650280218HW\t",1),
(7,7,"2023-08-24",7,"\t746502802182Y \t",1),
(8,8,"2023-08-25",8,"\t74650270217DB\t",1),
(9,9,"2023-08-26",9,"\t74650280218DM\t",1),
(10,10,"2023-08-27",10,"\t74650280218D1\t",1),
(11,11,"2023-08-28",11,"\t40648420133H1\t",1),
(12,12,"2023-08-29",12,"\t4064844013F8M\t",1),
(13,13,"2023-08-30",13,"\t50289500G4DZV\t",1),
(14,1,"2023-08-31",14,"\t4064844013GDY\t",1),
(15,2,"2023-09-01",15,"\t40648420133H1\t",1),
(16,3,"2023-09-02",16,"\t4064844013G9P\t",1);


DROP TABLE IF EXISTS `dispositivo`;

CREATE TABLE `dispositivo` (
  `idDispositivo` tinyint(3) NOT NULL,
  `idTipoDispositivo` tinyint(3) NOT NULL,
  `idModeloDispositivo` tinyint(3) NOT NULL,
  `numeroSerie` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `idIP` tinyint(3) NOT NULL,
  `idLocal` tinyint(3) NOT NULL,
  `idArea` tinyint(3) NOT NULL,
  `status` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idDispositivo`),
  KEY `fk_Dispositivo_TipoDispositivo1_idx` (`idTipoDispositivo`),
  KEY `fk_Dispositivo_ModeloDispositivo2_idx` (`idModeloDispositivo`),
  KEY `fk_Dispositivo_IP2_idx` (`idIP`),
  KEY `fk_Dispositivo_Area2_idx` (`idArea`),
  KEY `fk_Dispositivo_Local2_idx` (`idLocal`),
  CONSTRAINT `fk_Dispositivo_Area2` FOREIGN KEY (`idArea`) REFERENCES `area` (`idArea`),
  CONSTRAINT `fk_Dispositivo_IP2` FOREIGN KEY (`idIP`) REFERENCES `ip` (`idIP`),
  CONSTRAINT `fk_Dispositivo_Local2` FOREIGN KEY (`idLocal`) REFERENCES `local` (`idLocal`),
  CONSTRAINT `fk_Dispositivo_ModeloDispositivo2` FOREIGN KEY (`idModeloDispositivo`) REFERENCES `modelodispositivo` (`idModeloDispositivo`),
  CONSTRAINT `fk_Dispositivo_TipoDispositivo1` FOREIGN KEY (`idTipoDispositivo`) REFERENCES `tipodispositivo` (`idTipoDispositivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `dispositivo` VALUES (1,1,1,"\t74650280218G7\t",1,26,1,1,1),
(2,1,1,"\t74650290219F7\t",2,26,2,1,1),
(3,1,1,"\t74650280218KD\t",3,26,3,1,1),
(4,1,1,"\t 74650280218B3\t",4,26,4,1,1),
(5,1,1,"\t74650270217H3\t",5,26,5,1,1),
(6,1,1,"\t74650280218HW\t",6,26,6,1,1),
(7,1,1,"\t746502802182Y \t",7,26,7,1,1),
(8,2,2,"\t4064844013GDY\t",8,26,1,1,1),
(9,2,2,"\t40648420133H1\t",9,26,2,1,1),
(10,2,2,"\t4064844013G9P\t",10,26,3,1,1),
(11,2,2,"\t40648420133V5\t",11,26,4,1,1),
(12,2,2,"\t406484301397Y\t",12,26,5,1,1),
(13,2,2,"\t4064844013G9L\t",13,26,6,1,1),
(14,2,2,"\t40648420133PX\t",14,26,7,1,1),
(15,2,2,"\t40648420133MC\t",15,26,1,1,1),
(16,2,2,"\t40648420133MC\t",16,26,2,1,1),
(17,2,2,"\t406484201346M\t",17,26,3,1,1),
(18,2,2,"\t40648420133HW\t",18,26,4,1,1),
(19,3,3,"\t50289500G4DZV\t",19,26,5,1,1);


DROP TABLE IF EXISTS `estado`;

CREATE TABLE `estado` (
  `idEstado` tinyint(3) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idEstado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `estado` VALUES (1,"\tAguascalientes\t",1),
(2,"\tBaja California\t",1),
(3,"\tBaja California Sur\t",1),
(4,"\tCampeche\t",1),
(5,"\tChiapas\t",1),
(6,"\tChihuahua\t",1),
(7,"\tCoahuila\t",1),
(8,"\tColima\t",1),
(9,"\tDistrito Federal\t",1),
(10,"\tDurango\t",1),
(11,"\tGuanajuato\t",1),
(12,"\tGuerrero\t",1),
(13,"\tHidalgo\t",1),
(14,"\tJalisco\t",1),
(15,"\tMéxico\t",1),
(16,"\tMichoacán\t",1),
(17,"\tMorelos\t",1),
(18,"\tNayarit\t",1),
(19,"\tNuevo León\t",1),
(20,"\tOaxaca\t",1),
(21,"\tPuebla\t",1),
(22,"\tQuerétaro\t",1),
(23,"\tQuintana Roo\t",1),
(24,"\tSan Luis Potosí\t",1),
(25,"\tSinaloa\t",1),
(26,"\tSonora\t",1),
(27,"\tTabasco\t",1),
(28,"\tTamaulipas\t",1),
(29,"\tTlaxcala\t",1),
(30,"\tVeracruz\t",1),
(31,"\tYucatán\t",1),
(32,"\tZacatecas\t",1);


DROP TABLE IF EXISTS `ip`;

CREATE TABLE `ip` (
  `idIP` tinyint(3) NOT NULL,
  `direccion` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idIP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `ip` VALUES (1,"\t99.55.16.40\t",1),
(2,"\t99.55.16.22\t",1),
(3,"\t99.55.16.200\t",1),
(4,"\t99.55.16.197\t",1),
(5,"\t99.55.16.198\t",1),
(6,"\t99.55.16.191\t",1),
(7,"\t99.55.20.50\t",1),
(8,"\t99.55.24.34\t",1),
(9,"\t99.55.24.41\t",1),
(10,"\t99.55.24.151\t",1),
(11,"\t99.55.12.21\t",1),
(12,"\t99.55.12.22\t",1),
(13,"\t99.55.20.20\t",1),
(14,"\t99.55.20.107\t",1),
(15,"\t99.55.20.35\t",1),
(16,"\t99.55.40.185\t",1),
(17,"\t99.55.24.154\t",1),
(18,"\t99.55.24.159\t",1),
(19,"\t99.55.24.152\t",1),
(20,"\t99.55.24.80\t",1),
(21,"\t99.55.24.153\t",1),
(22,"\t99.55.24.42\t",1),
(23,"\t99.55.24.90\t",1),
(24,"\t99.55.40.47\t",1),
(25,"\t99.55.40.179\t",1),
(26,"\t99.55.40.192\t",1),
(27,"\t99.55.40.20\t",1),
(28,"\t99.55.40.22\t",1),
(29,"\t99.55.40.23\t",1),
(30,"\t99.55.40.183\t",1),
(31,"\t99.55.40.24\t",1),
(32,"\t99.55.40.25\t",1),
(33,"\t10.11.58.253\t",1),
(34,"\t10.11.58.254\t",1),
(35,"\t99.55.40.26\t",1),
(36,"\t99.55.40.27\t",1),
(37,"\t99.55.40.21\t",1),
(38,"\t99.55.40.180\t",1),
(39,"\t99.55.12.90\t",1);


DROP TABLE IF EXISTS `local`;

CREATE TABLE `local` (
  `idLocal` tinyint(3) NOT NULL,
  `idEstado` tinyint(3) NOT NULL,
  `idMunicipio` tinyint(3) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `status` tinyint(3) DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idLocal`),
  KEY `fk_Local_Estado1_idx` (`idEstado`),
  KEY `fk_Local_Municipio1_idx` (`idMunicipio`),
  CONSTRAINT `fk_Local_Estado1` FOREIGN KEY (`idEstado`) REFERENCES `estado` (`idEstado`),
  CONSTRAINT `fk_Local_Municipio1` FOREIGN KEY (`idMunicipio`) REFERENCES `municipio` (`idMunicipio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `local` VALUES (1,13,2,"\t496\t",1,1),
(2,13,3,"\t400\t",1,1),
(3,13,4,"\t340\t",1,1),
(4,13,5,"\t219\t",1,1),
(5,13,6,"\t523\t",1,1),
(6,15,7,"\t524\t",1,1),
(7,14,8,"\t525\t",1,1),
(8,19,9,"\t215\t",1,1),
(9,21,10,"\t1019\t",1,1),
(10,11,11,"\t1003\t",1,1),
(11,2,12,"\t514\t",1,1),
(12,6,13,"\t214\t",1,1),
(13,31,14,"\t1005\t",1,1),
(14,26,15,"\t379\t",1,1),
(15,25,16,"\t1008\t",1,1),
(16,1,17,"\t210\t",1,1),
(17,15,18,"\t564\t",1,1),
(18,16,19,"\t398\t",1,1),
(19,24,20,"\t399\t",1,1),
(20,22,21,"\t532\t",1,1),
(21,6,22,"\t490\t",1,1),
(22,20,23,"\t225\t",1,1),
(23,30,24,"\t407\t",1,1),
(24,32,25,"\t380\t",1,1),
(25,4,26,"\t220\t",1,1),
(26,13,1,"\t217\t",1,1);


DROP TABLE IF EXISTS `modelo`;

CREATE TABLE `modelo` (
  `idModelo` tinyint(3) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idModelo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `modelo` VALUES (1,"\tPaquetes tamaño Carta\t",1),
(2,"\tPaquetes tamaño oficio\t",1),
(3,"\tRollos de papel térmico\t",1),
(4,"\t58D4U00 (Negro)\t",1),
(5,"\tCN-3597 (NEGRO)\t",1),
(6,"\tCN-3740 (CIAN)\t",1),
(7,"\tCN-4097 (AMARILLO)\t",1),
(8,"\tCN-4100 (MAGENTA)\t",1),
(9,"\t58D0Z00\t",1),
(10,"\t41-X2233\t",1),
(11,"\tCN-3020 NEGRO 215\t",1),
(12,"\tCN-3021 TRICOLOR 215\t",1),
(13,"\tT29500\t",1),
(14,"\tCN-2653 (NEGROPHOTO)\t",1),
(15,"\tCN-2685 (negro mate)\t",1),
(16,"\tCN-2650 (CYAN)\t",1),
(17,"\tCN-2652 (AMARILLO)\t",1),
(18,"\tCN-2651 (MAGENTA)\t",1);


DROP TABLE IF EXISTS `modelo-producto`;

CREATE TABLE `modelo-producto` (
  `idModelo-Producto` int(11) NOT NULL,
  `idProducto` tinyint(3) NOT NULL,
  `idModelo` tinyint(3) NOT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idModelo-Producto`),
  KEY `fk_Modelo-Producto_Producto1_idx` (`idProducto`),
  KEY `fk_Modelo-Producto_Modelo1_idx` (`idModelo`),
  CONSTRAINT `fk_Modelo-Producto_Modelo1` FOREIGN KEY (`idModelo`) REFERENCES `modelo` (`idModelo`),
  CONSTRAINT `fk_Modelo-Producto_Producto1` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `modelo-producto` VALUES (1,1,1,1),
(2,2,2,1),
(3,3,3,1),
(4,4,4,1),
(5,5,5,1),
(6,6,6,1),
(7,7,7,1),
(8,8,8,1),
(9,9,9,1),
(10,10,10,1),
(11,11,11,1),
(12,12,12,1),
(13,13,13,1),
(14,1,14,1),
(15,2,15,1),
(16,3,16,1),
(17,4,17,1),
(18,5,18,1);


DROP TABLE IF EXISTS `modelodispositivo`;

CREATE TABLE `modelodispositivo` (
  `idModeloDispositivo` tinyint(3) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idModeloDispositivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `modelodispositivo` VALUES (1,"\tMX826ade\t",1),
(2,"\tMS826de\t",1),
(3,"\tCS7725de\t",1),
(4,"\tWF-100 \t",1),
(5,"\tFI-7700\t",1);


DROP TABLE IF EXISTS `municipio`;

CREATE TABLE `municipio` (
  `idMunicipio` tinyint(3) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idMunicipio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `municipio` VALUES (1,"\tPACHUCA\t",1),
(2,"\tIXMIQUILPAN\t",1),
(3,"\tMINERAL DE LA REFORMA\t",1),
(4,"\tHUEJUTLA\t",1),
(5,"\tTULA\t",1),
(6,"\tTULANCINGO\t",1),
(7,"\tCiudad de México\t",1),
(8,"\tGuadalajara\t",1),
(9,"\tMonterrey\t",1),
(10,"\tPuebla\t",1),
(11,"\tLeón\t",1),
(12,"\tTijuana\t",1),
(13,"\tCiudad Juárez\t",1),
(14,"\tMérida\t",1),
(15,"\tHermosillo\t",1),
(16,"\tCuliacán\t",1),
(17,"\tAguascalientes\t",1),
(18,"\tToluca\t",1),
(19,"\tMorelia\t",1),
(20,"\tSan Luis Potosí\t",1),
(21,"\tQuerétaro\t",1),
(22,"\tChihuahua\t",1),
(23,"\tOaxaca de Juárez\t",1),
(24,"\tXalapa\t",1),
(25,"\tZacatecas\t",1),
(26,"\tCampeche\t",1),
(27,"\tTuxtla Gutiérrez\t",1),
(28,"\tCuernavaca\t",1),
(29,"\tLa Paz\t",1),
(30,"\tColima\t",1),
(31,"\tMexicali\t",1),
(32,"\tVictoria\t",1),
(33,"\tTepic\t",1),
(34,"\tSaltillo\t",1),
(35,"\tDurango\t",1),
(36,"\tVillahermosa\t",1),
(37,"\tTlaxcala\t",1),
(38,"\tChilpancingo\t",1),
(39,"\tAguascalientes\t",1),
(40,"\tToluca\t",1),
(41,"\tGuanajuato\t",1),
(42,"\tCancún\t",1),
(43,"\tAcapulco\t",1),
(44,"\tEnsenada\t",1),
(45,"\tMazatlán\t",1),
(46,"\tReynosa\t",1),
(47,"\tMonclova\t",1),
(48,"\tSalamanca\t",1),
(49,"\tSan Juan del Río\t",1),
(50,"\tCoatzacoalcos\t",1),
(51,"\tCelaya\t",1),
(52,"\tLos Mochis\t",1),
(53,"\tTapachula\t",1),
(54,"\tPoza Rica\t",1),
(55,"\tCiudad del Carmen\t",1),
(56,"\tCuautitlán Izcalli\t",1),
(57,"\tSoledad de Graciano Sánchez\t",1),
(58,"\tCiudad Valles\t",1),
(59,"\tFresnillo\t",1),
(60,"\tVeracruz\t",1),
(61,"\tTonalá\t",1),
(62,"\tIxtapaluca\t",1),
(63,"\tCiudad López Mateos\t",1),
(64,"\tSan Cristóbal de las Casas\t",1),
(65,"\tSan Luis Río Colorado\t",1),
(66,"\tGuaymas\t",1),
(67,"\tNogales\t",1),
(68,"\tZamora\t",1),
(69,"\tTlaquepaque\t",1),
(70,"\tCiudad Obregón\t",1),
(71,"\tAtlixco\t",1),
(72,"\tPiedras Negras\t",1),
(73,"\tMonclova\t",1);


DROP TABLE IF EXISTS `producto`;

CREATE TABLE `producto` (
  `idProducto` tinyint(3) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `numeroSerie` varchar(60) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idProducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `producto` VALUES (1,"\tPAPEL\t","\tN/A\t",1),
(2,"\tTONER\t","\tWSDSF13143\t",1),
(3,"\tUNIDAD DE IMAGEN\t","\tSDSDS23424\t",1),
(4,"\tKIT MANTENIMIENTO\t","\tTHYTH2435\t",1),
(5,"\tCARTUCHO COLOR\t","\tN/A\t",1),
(6,"\tCARTUCHO TRICOLOR\t","\tN/A\t",1),
(7,"\tTANQUE MANTENIMIENTO\t","\tN/A\t",1),
(8,"\tKIT ADF\t","\tN/A\t",1),
(9,"\tTONER NEGRO\t","\tDFADFD242\t",1),
(10,"\tTONER CIAN\t","\tDFSSDSI232\t",1),
(11,"\tTONER MAGENTA\t","\tDFAELO261\t",1),
(12,"\tTONER AMARILLO\t","\tDFAHGL217\t",1),
(13,"\tUNIDAD RECOLECTORA\t","\tN/A\t",1);


DROP TABLE IF EXISTS `reporte`;

CREATE TABLE `reporte` (
  `idReporte` int(11) NOT NULL AUTO_INCREMENT,
  `idProducto` tinyint(3) NOT NULL,
  `cantidad` tinyint(4) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `idTecnico` int(11) NOT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idReporte`),
  KEY `fk_Reporte_Producto1_idx` (`idProducto`),
  KEY `fk_Reporte_Tecnico1_idx` (`idTecnico`),
  CONSTRAINT `fk_Reporte_Producto1` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`),
  CONSTRAINT `fk_Reporte_Tecnico1` FOREIGN KEY (`idTecnico`) REFERENCES `tecnico` (`idTecnico`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `reporte` VALUES (1,1,22,"2023-09-07",1,1),
(2,2,7,"2023-08-04",1,1),
(3,3,2,"2023-08-05",1,1),
(4,4,1,"2023-08-06",1,1),
(5,5,2,"2023-08-07",1,1),
(6,6,8,"2023-08-08",1,1),
(7,7,9,"2023-08-09",1,1),
(8,8,3,"2023-08-10",1,1),
(9,9,7,"2023-08-11",1,1),
(10,10,3,"2023-08-12",1,1),
(11,11,9,"2023-08-13",1,1),
(12,12,1,"2023-08-14",1,1),
(13,13,8,"2023-08-15",1,1),
(14,1,9,"2023-08-16",1,1),
(15,1,3,"2023-08-16",1,1),
(16,2,55,"2023-09-07",1,1),
(17,8,44,"2023-09-01",2,1),
(18,1,4,"2023-09-09",1,1);


DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `idStock` int(11) NOT NULL AUTO_INCREMENT,
  `idProducto` tinyint(3) NOT NULL,
  `status` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idStock`),
  KEY `fk_Stock_Producto1_idx` (`idProducto`),
  CONSTRAINT `fk_Stock_Producto1` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `stock` VALUES (1,1,1,12,"2023-07-21",1),
(2,2,1,45,"2023-07-21",1),
(3,3,1,3,"2023-07-21",1),
(4,4,1,3,"2023-07-21",1),
(5,5,1,9,"2023-07-21",1),
(6,6,1,7,"2023-07-21",1),
(7,7,1,5,"2023-07-21",1),
(8,8,1,3,"2023-07-21",1),
(9,9,1,5,"2023-07-21",1),
(10,10,1,11,"2023-07-21",1),
(11,11,1,6,"2023-07-21",1),
(12,12,1,7,"2023-07-21",1),
(13,13,1,2,"2023-07-21",1),
(14,1,1,6,"2023-07-21",1),
(15,2,1,8,"2023-07-21",1);


DROP TABLE IF EXISTS `tecnico`;

CREATE TABLE `tecnico` (
  `idTecnico` int(11) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `aPaterno` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `aMaterno` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fechaNacimiento` date DEFAULT NULL,
  `sexo` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `correo` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `status` tinyint(2) DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idTecnico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tecnico` VALUES (1,"\tJOSE MANUEL \t","\tRANGEL \t","\tCORTES\t","1992-05-13","\tM\t","\txflap13@hotmail.com\t",7713013483,1,1),
(2,"\tGabriela\t","\tMorales \t","\tRíos\t","1993-09-18","\t F     \t","\tgabriela@example.com\t",5555678901,1,1),
(3,"\tAndrés\t","\tDíaz\t","\tNavarro\t","1988-06-09","\tM\t","\tandres@example.com       \t",5550123456,1,1),
(4,"\tJuan\t","\tPérez\t","\tGarcía\t","1990-05-15","\tM\t","\tjuan@example.com\t",5551234567,1,1),
(5,"\tMaría\t","\tLópez\t","\tRodríguez\t","1985-12-03","\tF\t","\tmaria@example.com\t",5559876543,1,1),
(6,"\tCarlos\t","\tGonzález\t","\tSánchez\t","2000-08-22","\tM\t","\tcarlos@example.com\t",5557891234,1,1),
(7,"\tLaura\t","\tTorres\t","\tFernández\t","1998-07-10","\tF\t","\tlaura@example.com\t",5552345678,1,1),
(8,"\tPedro\t","\tRamírez\t","\tDíaz\t","1977-02-28","\tM\t","\tpedro@example.com\t",5553456789,1,1),
(9,"\tAna\t","\tMartínez\t","\tRuiz\t","1995-11-12","\tF\t","\tana@example.com\t",5558765432,1,1),
(10,"\tLuis\t","\tSoto\t","\tVargas\t","1989-09-19","\tM\t","\tluis@example.com\t",5552345678,1,1),
(11,"\tSofía\t","\tCastro\t","\tOrtega\t","2002-06-07","\tF\t","\tsofia@example.com\t",5556789012,1,1),
(12,"\tDiego\t","\tSilva\t","\tFuentes\t","1982-04-30","\tM\t","\tdiego@example.com\t",5553456789,1,1),
(13,"\tCarmen\t","\tMendoza\t","\tParedes\t","1974-01-25","\tF\t","\tcarmen@example.com\t",5557890123,1,1),
(14,"\tRaquel\t","\tDelgado\t","\tJiménez \t","1979-03-27","\tF\t","\t  raquel@example.com       \t",5554567890,1,1),
(15,"\tEmilio\t","\tVargas\t","\tCervantes\t","2001-02-14","\tM\t","\temilio@example.com       \t",5558901234,1,1),
(16,"\tAdriana\t","\tParedes\t","\tSilva\t","1996-11-08","\tF\t","\tadriana@example.com      \t",5552345678,1,1),
(17,"\tSergio\t","\tGuzmán\t","\tOrtega\t","1984-10-05","\tM\t","\tsergio@example.com       \t",5556789012,1,1),
(18,"\t Isabel    \t","\tFuentes\t","\tSoto\t","1975-07-23","\tF\t","\tisabel@example.com       \t",5553456789,1,1),
(19,"\tEduardo\t","\tRíos\t","\tMendoza\t","2003-04-17","\tM\t","\teduardo@example.com      \t",5557890123,1,1),
(20,"\tCarmen\t","\tNavarro\t","\tTorres\t","1987-01-02","\tF\t","\tcarmen@example.com       \t",5559012345,1,1),
(21,"\tMarco\t","\tJiménez\t","\tCastro\t","1992-08-20","\tM\t","\tmarco@example.com        \t",5553456789,1,1),
(22,"\tPatricia         \t","\tSilva\t","\tMorales\t","1978-05-11","\t F     \t","\tpatricia@example.com     \t",5556789012,1,1);


DROP TABLE IF EXISTS `tipodispositivo`;

CREATE TABLE `tipodispositivo` (
  `idTipoDispositivo` tinyint(3) NOT NULL,
  `nombre` varchar(45) COLLATE utf8_spanish_ci DEFAULT NULL,
  `statusV` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idTipoDispositivo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `tipodispositivo` VALUES (1,"\tMULTIFUNCIONAL BAJO VOLUMEN\t",1),
(2,"\tIMPRESORA B&N\t",1),
(3,"\tIMPRESORA COLOR\t",1),
(4,"\tIMPRESORA PORTATIL\t",1),
(5,"\tESCANER PORTATIL\t",1),
(6,"\tESCANER FUJITSU\t",1),
(7,"\tIMPRESORA TERMICA\t",1);


SET foreign_key_checks = 1;
